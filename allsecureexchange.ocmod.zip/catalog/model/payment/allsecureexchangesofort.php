<?php
namespace Opencart\Catalog\Model\Extension\Allsecureexchange\Payment;

require_once DIR_EXTENSION.'allsecureexchange/catalog/model/payment/allsecureexchange.php';

class AllsecureexchangeSofort extends Allsecureexchange
{
    protected $code = 'sofort';
}