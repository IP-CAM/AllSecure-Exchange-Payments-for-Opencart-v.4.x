<?php
namespace Opencart\Catalog\Controller\Extension\Allsecureexchange\Payment;

require_once DIR_EXTENSION.'allsecureexchange/catalog/controller/payment/allsecureexchange.php';

class AllsecureexchangeSofort extends Allsecureexchange
{
    protected $code = 'sofort';
}