# Release Notes

## v1.0.0 (2023-06-01)
### Added
- Initial version for OpenCart4