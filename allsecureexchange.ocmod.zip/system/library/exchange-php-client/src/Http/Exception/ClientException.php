<?php


namespace Exchange\Client\Http\Exception;

/**
 * Class ClientException
 *
 * @package Exchange\Client\Http\Exception
 */
class ClientException extends \Exception {

}