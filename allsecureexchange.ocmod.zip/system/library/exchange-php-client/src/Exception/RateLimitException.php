<?php

namespace Exchange\Client\Exception;

/**
 * Class RateLimitException
 *
 * @package Exchange\Client\Exception
 */
class RateLimitException extends \Exception {

}