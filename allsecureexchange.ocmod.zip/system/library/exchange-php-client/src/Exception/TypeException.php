<?php

namespace Exchange\Client\Exception;

/**
 * Class TypeException
 *
 * @package Exchange\Client\Exception
 */
class TypeException extends ClientException {

}