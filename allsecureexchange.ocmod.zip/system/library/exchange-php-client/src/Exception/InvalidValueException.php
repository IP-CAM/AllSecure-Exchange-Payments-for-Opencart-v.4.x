<?php

namespace Exchange\Client\Exception;

/**
 * Class InvalidValueException
 *
 * @package Exchange\Client\Exception
 */
class InvalidValueException extends ClientException {

}