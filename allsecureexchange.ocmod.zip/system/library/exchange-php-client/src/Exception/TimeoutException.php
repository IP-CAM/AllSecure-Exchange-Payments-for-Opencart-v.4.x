<?php

namespace Exchange\Client\Exception;

/**
 * Class TimeoutException
 *
 * @package Exchange\Client\Exception
 */
class TimeoutException extends ClientException {

}