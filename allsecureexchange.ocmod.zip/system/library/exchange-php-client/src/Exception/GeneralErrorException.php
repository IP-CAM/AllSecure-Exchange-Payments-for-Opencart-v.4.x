<?php

namespace Exchange\Client\Exception;

/**
 * Class GeneralErrorException
 *
 * @package Exchange\Client\Exception
 */
class GeneralErrorException extends \Exception {

}