<?php

namespace Exchange\Client\Exception;

/**
 * Class ClientException
 *
 * @package Exchange\Client\Exception
 */
class ClientException extends \Exception {

}