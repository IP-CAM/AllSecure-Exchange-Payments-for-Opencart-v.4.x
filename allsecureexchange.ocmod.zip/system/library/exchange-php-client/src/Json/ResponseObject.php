<?php

namespace Exchange\Client\Json;

/**
 * Class ResponseObject
 *
 * @package Exchange\Client\Json
 *
 * @property bool $success
 */
class ResponseObject extends DataObject {

}