<?php

namespace Exchange\Client\CustomerProfile\PaymentData;

use Exchange\Client\Json\DataObject;

/**
 * Class PaymentData
 *
 * @package Exchange\Client\CustomerProfile\PaymentData
 */
abstract class PaymentData extends DataObject {

}