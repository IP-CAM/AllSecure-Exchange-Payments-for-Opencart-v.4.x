<?php

namespace Exchange\Client\CustomerProfile;

use Exchange\Client\Json\ResponseObject;

/**
 * Class DeleteProfileResponse
 *
 * @package Exchange\Client\CustomerProfile
 *
 */
class DeleteProfileResponse extends ResponseObject {

}