<?php
namespace Opencart\Admin\Controller\Extension\Allsecureexchange\Payment;

require_once DIR_EXTENSION.'allsecureexchange/admin/controller/payment/allsecureexchange.php';

class AllsecureexchangeSofort extends Allsecureexchange
{
    protected $code = 'sofort';
}