<?php
$_['heading_title'] = 'AllSecure Exchange Sofort';
$_['text_edit'] = 'Edit '.$_['heading_title'];
